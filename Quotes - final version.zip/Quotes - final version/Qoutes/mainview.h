#ifndef MAINVIEW_H
#define MAINVIEW_H


class MainView
{
public:
    MainView();
};

#endif // MAINVIEW_H
